# Streamlit Interactive ML Web App: Titanic Survival Prediction

## Project overview
This project demonstrates how to save a trained machine-learning pipeline and use it in an interactive Streamlit web application. A user enters ticket class, sex, age and fare, then receives a predicted class and estimated probability.

**Dataset note:** `titanic_sample.csv` is a simulated educational dataset generated for this project. It is not the original Titanic passenger dataset. Results are demonstrations only and should not be interpreted as historical findings.

## Files
- `app.py` — Streamlit user interface and prediction.
- `train_model.py` — trains and saves the machine-learning pipeline.
- `model.joblib` — saved trained model.
- `titanic_sample.csv` — simulated training data.
- `requirements.txt` — Python package dependencies.

## Run on your computer
1. Install Python 3.10 or newer.
2. Extract the project ZIP and open a terminal in this folder.
3. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
4. Train the model:
   ```bash
   python train_model.py
   ```
5. Start the app:
   ```bash
   streamlit run app.py
   ```
6. Open the local address shown in the terminal (usually `http://localhost:8501`).

## Deploy free with Streamlit Community Cloud
1. Create a GitHub account and a new **public** repository.
2. Upload `app.py`, `train_model.py`, `model.joblib`, `titanic_sample.csv`, and `requirements.txt`.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Select **Create app**, choose your repository, branch and `app.py`.
5. Click **Deploy** and wait for the app to start.
6. Open the public app link and test a prediction.
7. Capture a screenshot showing the inputs and prediction result.

## What to submit
- Public deployed Streamlit app URL.
- GitHub repository URL.
- Screenshot of a prediction.
- This project folder/ZIP if your teacher requests the source files.

## Checklist
- [ ] Model loads from `model.joblib`.
- [ ] Inputs have sensible limits.
- [ ] Prediction and probability are displayed.
- [ ] Missing model file shows a friendly message.
- [ ] `requirements.txt` lists the packages.
- [ ] Deployed app link works.
- [ ] GitHub repository link is accessible.

## Limitations
The dataset is simulated and the model is for learning how to build and deploy an ML app. It is not suitable for historical research or real-world decisions.
