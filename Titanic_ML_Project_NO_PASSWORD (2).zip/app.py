import os
import joblib
import pandas as pd
import streamlit as st

FEATURES = ["pclass", "sex", "age", "fare"]

st.set_page_config(page_title="Titanic Survival Predictor", page_icon="🚢", layout="centered")

@st.cache_resource
def load_model():
    return joblib.load("model.joblib")

st.title("🚢 Titanic Survival Prediction")
st.write(
    "Enter passenger details to see an educational machine-learning prediction. "
    "This model was trained on simulated Titanic-style data, not original passenger records."
)

if not os.path.exists("model.joblib"):
    st.error("The model file is missing. Run `python train_model.py` first.")
    st.stop()

try:
    model = load_model()
except Exception as error:
    st.error("The model could not be loaded. Please retrain it using train_model.py.")
    st.stop()

st.subheader("Passenger details")
col1, col2 = st.columns(2)

with col1:
    pclass = st.selectbox("Ticket class", [1, 2, 3], index=2)
    sex = st.radio("Sex", ["female", "male"], horizontal=True)

with col2:
    age = st.slider("Age", min_value=1, max_value=80, value=25)
    fare = st.slider("Fare paid", min_value=0.0, max_value=500.0, value=30.0, step=1.0)

if st.button("Predict survival", type="primary", use_container_width=True):
    try:
        input_data = pd.DataFrame(
            [[pclass, sex, age, fare]],
            columns=FEATURES
        )
        probabilities = model.predict_proba(input_data)[0]
        class_index = list(model.classes_).index(1)
        survival_probability = float(probabilities[class_index])
        prediction = int(model.predict(input_data)[0])

        st.subheader("Prediction result")
        st.metric("Estimated survival probability", f"{survival_probability * 100:.1f}%")
        if prediction == 1:
            st.success("The model predicts: More likely to survive.")
        else:
            st.warning("The model predicts: Less likely to survive.")
        st.progress(survival_probability)
        st.caption(
            "Educational demonstration only. This prediction is based on simulated training data "
            "and must not be treated as a historical fact or real-world decision."
        )
    except (ValueError, KeyError, TypeError) as error:
        st.error(f"Please check the entered values. Details: {error}")

st.divider()
st.caption("Machine Learning mini project | Python, Pandas, Scikit-learn and Streamlit")
