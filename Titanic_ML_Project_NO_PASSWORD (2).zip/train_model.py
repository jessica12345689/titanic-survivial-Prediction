"""
Train an educational Titanic-style survival classifier.
NOTE: titanic_sample.csv is simulated data, not original Titanic passenger records.
"""
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

FEATURES = ["pclass", "sex", "age", "fare"]
TARGET = "survived"

df = pd.read_csv("titanic_sample.csv")
X = df[FEATURES]
y = df[TARGET]

numeric_features = ["pclass", "age", "fare"]
categorical_features = ["sex"]

preprocessor = ColumnTransformer(
    transformers=[
        ("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ]), numeric_features),
        ("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ]), categorical_features)
    ]
)

model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(
        n_estimators=200, random_state=42, class_weight="balanced"
    ))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)
model.fit(X_train, y_train)

predictions = model.predict(X_test)
print("Model accuracy:", round(accuracy_score(y_test, predictions) * 100, 2), "%")
print(classification_report(y_test, predictions))

# Save the complete preprocessing + model pipeline.
joblib.dump(model, "model.joblib")
print("Saved model.joblib successfully.")
